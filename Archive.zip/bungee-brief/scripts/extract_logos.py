import pymupdf, json

AI = '/home/project/bungee-brief/extracted/Bungee-Fly-Brand-Guidelines-all-pages.ai'
OUT_SVG = '/home/project/bungee-fly/src/components/brand/svg'
OUT_JSON = '/home/project/bungee-brief/scripts/logos.json'

d = pymupdf.open(AI)
dr = d[0].get_drawings()
groups = {
    'vertical': range(8, 41),
    'horizontal': range(77, 93),
    'wordmark-latin': range(112, 126),
    'wordmark-arabic': range(143, 160),
    'symbol': [180],
}


def f(v):
    return f"{v:.3f}".rstrip('0').rstrip('.')


out = {}
for name, idxs in groups.items():
    paths = []
    x0 = y0 = 1e9
    x1 = y1 = -1e9
    for i in idxs:
        r = dr[i]['rect']
        x0, y0, x1, y1 = min(x0, r.x0), min(y0, r.y0), max(x1, r.x1), max(y1, r.y1)
    for i in idxs:
        x = dr[i]
        parts = []
        cur = None

        def P(p):
            return f"{f(p.x - x0)} {f(p.y - y0)}"

        for it in x['items']:
            t = it[0]
            if t == 're':
                rr = it[1]
                parts.append(f"M{f(rr.x0-x0)} {f(rr.y0-y0)}H{f(rr.x1-x0)}V{f(rr.y1-y0)}H{f(rr.x0-x0)}Z")
                cur = None
                continue
            if t == 'qu':
                q = it[1]
                parts.append(f"M{P(q.ul)}L{P(q.ur)}L{P(q.lr)}L{P(q.ll)}Z")
                cur = None
                continue
            p1 = it[1]
            if cur is None or abs(cur.x - p1.x) > 1e-3 or abs(cur.y - p1.y) > 1e-3:
                if cur is not None and x.get('closePath'):
                    parts.append('Z')
                parts.append(f"M{P(p1)}")
            if t == 'l':
                parts.append(f"L{P(it[2])}")
                cur = it[2]
            elif t == 'c':
                parts.append(f"C{P(it[2])} {P(it[3])} {P(it[4])}")
                cur = it[4]
        if x.get('closePath'):
            parts.append('Z')
        rule = 'evenodd' if x.get('even_odd') else 'nonzero'
        paths.append({'d': ''.join(parts), 'rule': rule})
    w, h = x1 - x0, y1 - y0
    body = ''.join(f'<path fill-rule="{p["rule"]}" d="{p["d"]}"/>' for p in paths)
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {f(w)} {f(h)}" fill="currentColor">{body}</svg>'
    open(f'{OUT_SVG}/{name}.svg', 'w').write(svg)
    out[name] = {'w': round(w, 3), 'h': round(h, 3), 'paths': paths}
    print(name, round(w, 2), round(h, 2))
json.dump(out, open(OUT_JSON, 'w'))
