import os
from fontTools import subset

SRC = '/home/project/bungee-brief/extracted/inner'
P = '/home/project/bungee-fly'
os.makedirs(f'{P}/src/app/fonts', exist_ok=True)
os.makedirs(f'{P}/public/fonts', exist_ok=True)

LATIN = ('U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,'
         'U+2074,U+20AC,U+2122,U+2190-2199,U+2212,U+2215,U+00D7')
# Arabic + presentation forms + ZWNJ/ZWJ/marks, plus digits & basic punctuation so mixed runs stay in one face.
ARABIC = 'U+0020-0040,U+0600-06FF,U+0750-077F,U+08A0-08FF,U+FB50-FDFF,U+FE70-FEFF,U+200C-200F,U+2010-2027'


def run(src, out, ranges):
    opts = subset.Options()
    opts.flavor = 'woff2'
    opts.layout_features = ['*']  # keep Arabic shaping (init/medi/fina/liga/mark/mkmk/rlig)
    opts.name_IDs = ['*']
    opts.hinting = False
    opts.desubroutinize = True
    font = subset.load_font(src, opts)
    s = subset.Subsetter(opts)
    s.populate(unicodes=subset.parse_unicodes(ranges))
    s.subset(font)
    subset.save_font(font, out, opts)
    print(os.path.basename(out), os.path.getsize(out))


for w, n in [('Regular', 'regular'), ('Medium', 'medium'), ('SemiBold', 'semibold'), ('Bold', 'bold')]:
    run(f'{SRC}/IBMPlexSans-{w}.ttf', f'{P}/src/app/fonts/plex-sans-{n}.woff2', LATIN)

for w, n in [('Regular', 400), ('Medium', 500), ('SemiBold', 600), ('Bold', 700)]:
    run(f'{SRC}/IBMPlexSansArabic-{w}.ttf', f'{P}/public/fonts/plex-arabic-{n}.v1.woff2', ARABIC)
