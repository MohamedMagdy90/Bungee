import json, os
from PIL import Image, ImageDraw
import pymupdf
P = '/home/project/bungee-fly'
# 1. Logo TS module
L = json.load(open('/home/project/bungee-brief/scripts/logos.json'))
lines = ['// Generated from the master Illustrator artwork (Bungee-Fly-Brand-Guidelines-all-pages.ai).', '// Do not redraw or edit by hand. Single colour only: paths inherit currentColor.', '', 'export type LogoPath = { d: string; rule: "evenodd" | "nonzero" };', 'export type LogoArt = { w: number; h: number; paths: LogoPath[] };', '', 'export const LOGOS = {']
for k,v in L.items():
    key = k.replace('-', '_')
    lines.append(f'  {json.dumps(k)}: {{ w: {v["w"]}, h: {v["h"]}, paths: [')
    for p in v['paths']:
        lines.append(f'    {{ d: {json.dumps(p["d"])}, rule: {json.dumps(p["rule"])} }},')
    lines.append('  ] },')
lines.append('} satisfies Record<string, LogoArt>;')
lines.append('')
lines.append('export type LogoVariant = keyof typeof LOGOS;')
open(f'{P}/src/components/brand/logo-art.ts','w').write('\n'.join(lines)+'\n')

# 2. Placeholder photography -> webp
src = '/home/project/bungee-brief/extracted/photos'
os.makedirs(src, exist_ok=True)
_pdf = pymupdf.open('/home/project/bungee-brief/extracted/Bungee-Fly-Brand-Guidelines-all-pages.pdf')
for _i, _pg in enumerate(_pdf):
    for _im in _pg.get_images(full=True):
        _info = _pdf.extract_image(_im[0])
        open(f'{src}/p{_i+1:02d}_{_im[0]}.{_info["ext"]}', 'wb').write(_info['image'])
dst = f'{P}/public/media/placeholder'; os.makedirs(dst, exist_ok=True)
picks = {
  'p18_1797.jpeg': ('hero-lift', 1680),
  'p18_1798.jpeg': ('class-inversion', 1200),
  'p18_1799.jpeg': ('cord-grip', 1200),
  'p18_1800.jpeg': ('class-motion', 1200),
  'p19_1872.jpeg': ('studio-class', 1400),
  'p20_1899.jpeg': ('kit-bottle', 900),
  'p20_1902.jpeg': ('kit-mat', 900),
  'p20_1900.jpeg': ('kit-cap', 900),
}
for f,(name,maxw) in picks.items():
    im = Image.open(f'{src}/{f}').convert('RGB')
    if im.width > maxw: im = im.resize((maxw, round(im.height*maxw/im.width)), Image.LANCZOS)
    im.save(f'{dst}/{name}.webp', 'WEBP', quality=80, method=6)
    print(name, im.size, os.path.getsize(f'{dst}/{name}.webp'))

# 3. App icons: symbol in Ice Grey on Deep Navy
sym = L['symbol']
def render_symbol(size, pad_ratio, bg, fg, radius_ratio=0.0):
    w,h = sym['w'], sym['h']
    inner = size*(1-2*pad_ratio)
    scale = inner/max(w,h)
    tx = (size - w*scale)/2; ty = (size - h*scale)/2
    body = ''.join(f'<path fill-rule="{p["rule"]}" d="{p["d"]}"/>' for p in sym['paths'])
    r = size*radius_ratio
    bgrect = f'<rect width="{size}" height="{size}" rx="{r}" fill="{bg}"/>' if bg else ''
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 {size} {size}">{bgrect}<g transform="translate({tx} {ty}) scale({scale})" fill="{fg}">{body}</g></svg>'
    doc = pymupdf.open(stream=svg.encode(), filetype='svg')
    pix = doc[0].get_pixmap(alpha=bg is None)
    return pix, svg
os.makedirs(f'{P}/public/icons', exist_ok=True)
for size in (192, 512):
    pix,_ = render_symbol(size, 0.2, '#0B1F33', '#E7EBED'); pix.save(f'{P}/public/icons/icon-{size}.png')
    pix,_ = render_symbol(size, 0.28, '#0B1F33', '#E7EBED'); pix.save(f'{P}/public/icons/maskable-{size}.png')
pix,_ = render_symbol(180, 0.2, '#0B1F33', '#E7EBED'); pix.save(f'{P}/src/app/apple-icon.png')
_, svg = render_symbol(64, 0.14, '#0B1F33', '#E7EBED', 0.22)
open(f'{P}/src/app/icon.svg','w').write(svg)
print('icons done')
