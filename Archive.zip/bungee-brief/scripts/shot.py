import sys, asyncio
from playwright.async_api import async_playwright

# usage: python3 shot.py <path> <out.png> <width> <height> [full]
async def main():
    path, out, w, h = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
    full = len(sys.argv) > 5 and sys.argv[5] == 'full'
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--no-sandbox'])
        ctx = await b.new_context(viewport={'width': w, 'height': h}, device_scale_factor=1, reduced_motion='reduce')
        page = await ctx.new_page()
        errors = []
        page.on('console', lambda m: errors.append(f'{m.type}: {m.text}') if m.type in ('error', 'warning') else None)
        page.on('pageerror', lambda e: errors.append(f'pageerror: {e}'))
        await page.goto(f'http://localhost:3000{path}', wait_until='networkidle', timeout=180000)
        await page.wait_for_timeout(2500)
        # force reveal everything for full-page captures
        await page.evaluate("document.querySelectorAll('[data-reveal]').forEach(e=>e.classList.add('is-in'))")
        if full:
            # scroll through so lazy images load, then back to top
            await page.evaluate("""async () => {
                const step = window.innerHeight * 0.8;
                for (let y = 0; y < document.body.scrollHeight; y += step) {
                    window.scrollTo(0, y); await new Promise(r => setTimeout(r, 250));
                }
                window.scrollTo(0, 0);
            }""")
            await page.wait_for_timeout(1500)
        await page.wait_for_timeout(600)
        await page.screenshot(path=out, full_page=full)
        for e in errors[:15]:
            print(e[:300])
        await b.close()

asyncio.run(main())
