BUNGEE FLY - HIGH RESOLUTION LOGOS

10 original logo variants extracted from the supplied Illustrator file.
Each WebP is 4096 pixels on its longest edge, with a transparent background.
Lossless encoding; original vector geometry and source colours preserved.
Navy variants suit light backgrounds. Light variants suit dark backgrounds.
A small transparent margin protects the logo edges.

Bungee-Fly-Primary-Vertical-Navy.webp - 4096 x 2434 px
Bungee-Fly-Primary-Vertical-Light.webp - 4096 x 2434 px
Bungee-Fly-Secondary-Horizontal-Navy.webp - 4096 x 1128 px
Bungee-Fly-Secondary-Horizontal-Light.webp - 4096 x 1128 px
Bungee-Fly-Latin-Wordmark-Navy.webp - 4096 x 525 px
Bungee-Fly-Latin-Wordmark-Light.webp - 4096 x 525 px
Bungee-Fly-Arabic-Wordmark-Navy.webp - 4096 x 692 px
Bungee-Fly-Arabic-Wordmark-Light.webp - 4096 x 692 px
Bungee-Fly-Symbol-Navy.webp - 4096 x 3487 px
Bungee-Fly-Symbol-Light.webp - 4096 x 3487 px
