import "server-only";
import { STUDIO_TZ } from "@/lib/constants";
import { fmtLongDate, fmtTime } from "@/lib/format";
import { ticketUrl } from "../booking/ticket";
import type { EmailTemplate } from "../notify";

export type RenderedEmail = {
  subject: string;
  heading: string;
  lines: string[];
  action?: { label: string; url: string };
  html: string;
  dir: "ltr" | "rtl";
};

type Payload = Record<string, unknown>;
const str = (v: unknown) => (typeof v === "string" ? v : "");
const num = (v: unknown) => (typeof v === "number" ? v : 0);

/** "Bungee Burn · Tuesday 3 November · 06:30 · West Bay" in the recipient's language. */
function classLine(p: Payload, ar: boolean) {
  const tz = str(p.timezone) || STUDIO_TZ;
  const locale = ar ? "ar" : "en";
  const startsAt = str(p.startsAt);
  const when = startsAt ? `${fmtLongDate(startsAt, locale, tz)} · ${fmtTime(startsAt, locale, tz)}` : "";
  const cls = ar ? str(p.classAr) || str(p.classEn) : str(p.classEn);
  const branch = ar ? str(p.branchAr) || str(p.branchEn) : str(p.branchEn);
  return [cls, when, branch].filter(Boolean).join(" · ");
}

const firstName = (p: Payload) => str(p.name).split(" ")[0] || str(p.name);

function content(template: EmailTemplate, p: Payload, ar: boolean, origin: string) {
  const hi = ar ? `مرحبًا ${firstName(p)}،` : `Hi ${firstName(p)},`;
  const locale = ar ? "ar" : "en";
  const code = str(p.code);
  const ticket = code ? { label: ar ? "اعرض تذكرتك" : "View your ticket", url: ticketUrl(origin, locale, code) } : undefined;
  switch (template) {
    case "auth.verify_email":
      return {
        subject: ar ? "فعّل حسابك في بانجي فلاي" : "Verify your Bungee Fly account",
        heading: ar ? "خطوة أخيرة." : "One last step.",
        lines: [
          hi,
          ar
            ? "اضغط الزر أدناه لتفعيل بريدك وبدء الحجز. الرابط صالح لمدة 24 ساعة."
            : "Tap the button below to verify your email and start booking. The link works for 24 hours.",
          ar ? "إذا لم تنشئ حسابًا، تجاهل هذه الرسالة." : "If you didn't create an account, ignore this email.",
        ],
        action: { label: ar ? "فعّل بريدي" : "Verify my email", url: str(p.url) },
      };
    case "auth.reset_password":
      return {
        subject: ar ? "إعادة تعيين كلمة المرور" : "Reset your password",
        heading: ar ? "إعادة تعيين كلمة المرور." : "Reset your password.",
        lines: [
          hi,
          ar ? "طلبت إعادة تعيين كلمة المرور. الرابط صالح لمدة ساعة." : "You asked to reset your password. The link works for 1 hour.",
          ar ? "إذا لم تطلب ذلك، تجاهل هذه الرسالة ولن يتغير شيء." : "If you didn't ask, ignore this email and nothing changes.",
        ],
        action: { label: ar ? "اختر كلمة مرور جديدة" : "Choose a new password", url: str(p.url) },
      };
    case "booking.confirmed":
      return {
        subject: ar ? `تم تأكيد حجزك · ${code}` : `You're booked · ${code}`,
        heading: ar ? "تم الحجز." : "You're booked.",
        lines: [
          hi,
          classLine(p, ar),
          ar
            ? `المرجع: ${code}. أظهر رمز QR في تذكرتك عند مكتب الاستقبال.`
            : `Reference ${code}. Show the QR code on your ticket at the front desk.`,
          ar ? `الحصص المتبقية في باقتك: ${num(p.creditsLeft)}.` : `Sessions left on your pack: ${num(p.creditsLeft)}.`,
          ar ? "احضر قبل 10 دقائق بملابس رياضية مريحة." : "Arrive 10 minutes early in comfortable sportswear.",
        ],
        action: ticket,
      };
    case "booking.waitlisted":
      return {
        subject: ar ? "أنت على قائمة الانتظار" : "You're on the waitlist",
        heading: ar ? `ترتيبك ${num(p.position)} في قائمة الانتظار.` : `You're #${num(p.position)} on the waitlist.`,
        lines: [
          hi,
          classLine(p, ar),
          ar
            ? "لن تُخصم أي حصة الآن. إذا توفّر مكان قبل الحصة فسنحجزه لك تلقائيًا ونراسلك."
            : "No session has been used. If a spot opens before class, we'll book you in automatically and email you.",
        ],
        action: undefined,
      };
    case "booking.promoted":
      return {
        subject: ar ? "توفّر مكان: تم حجزك" : "A spot opened: you're booked",
        heading: ar ? "توفّر مكان لك." : "A spot opened up.",
        lines: [
          hi,
          classLine(p, ar),
          ar
            ? `انتقلت من قائمة الانتظار إلى الحجز. الحصص المتبقية: ${num(p.creditsLeft)}.`
            : `You've moved from the waitlist into the class. Sessions left: ${num(p.creditsLeft)}.`,
        ],
        action: ticket,
      };
    case "booking.cancelled":
      return {
        subject: ar ? "تم إلغاء حجزك" : "Booking cancelled",
        heading: ar ? "تم الإلغاء." : "Booking cancelled.",
        lines: [
          hi,
          classLine(p, ar),
          p.refunded
            ? ar
              ? "عادت الحصة إلى باقتك."
              : "The session is back in your pack."
            : ar
              ? "كان الإلغاء متأخرًا، لذا لم تُسترد الحصة."
              : "This was a late cancellation, so the session wasn't refunded.",
        ],
        action: undefined,
      };
  }
}

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

/** Table-based, inline-styled HTML (email clients), mirrored for Arabic. Brand: navy band, orange action. */
function toHtml(c: { heading: string; lines: string[]; action?: { label: string; url: string } }, dir: "ltr" | "rtl") {
  const font = dir === "rtl" ? "'IBM Plex Sans Arabic',Tahoma,Arial,sans-serif" : "'IBM Plex Sans',Helvetica,Arial,sans-serif";
  const align = dir === "rtl" ? "right" : "left";
  const body = c.lines
    .map((l) => `<p style="margin:0 0 14px;font-size:16px;line-height:1.6;color:#0B1F33">${esc(l)}</p>`)
    .join("");
  const button = c.action
    ? `<p style="margin:24px 0 8px"><a href="${esc(c.action.url)}" style="display:inline-block;background:#FF642E;color:#0B1F33;font-weight:600;text-decoration:none;padding:14px 26px;border-radius:999px">${esc(c.action.label)}</a></p>`
    : "";
  return `<!doctype html><html dir="${dir}"><body style="margin:0;background:#E7EBED;font-family:${font}"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:24px 12px"><table role="presentation" width="100%" style="max-width:560px;background:#ffffff;border-radius:16px;overflow:hidden" cellpadding="0" cellspacing="0"><tr><td style="background:#0B1F33;padding:22px 28px;color:#E7EBED;font-size:13px;letter-spacing:.2em;text-align:${align}">BUNGEE FLY</td></tr><tr><td style="padding:28px;text-align:${align}"><h1 style="margin:0 0 18px;font-size:26px;line-height:1.2;color:#0B1F33">${esc(c.heading)}</h1>${body}${button}</td></tr></table></td></tr></table></body></html>`;
}

/** One renderer for the preview mailbox now and the outbox worker (Phase 4). R6: Arabic by recipient locale. */
export function renderEmail(template: EmailTemplate, payload: Payload, locale: string, origin: string): RenderedEmail {
  const ar = locale === "ar";
  const c = content(template, payload, ar, origin);
  const dir = ar ? "rtl" : "ltr";
  return { ...c, dir, html: toHtml(c, dir) };
}
